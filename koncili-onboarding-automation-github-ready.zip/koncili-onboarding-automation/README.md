# Koncili Onboarding Automation

Automação operacional para solicitação de criação de e-mails de onboarding de sellers.

## Stack

- Power Automate
- Azure DevOps Boards
- Azure DevOps Work Item API
- Office 365 Outlook
- Koncili

## Fluxo operacional

1. Um card **ADHERENCE KONCILI** é movido para **Fila Seller**.
2. O fluxo valida a coluna do board.
3. O fluxo verifica se o card já possui a tag `EMAILS_CRIADOS`.
4. Se ainda não foi processado, busca os dados do Work Item.
5. Normaliza o nome do seller para gerar o slug.
6. Gera os 10 aliases de e-mail.
7. Envia a solicitação ao Helpdesk.
8. Comenta no próprio card **ADHERENCE KONCILI**.
9. Comenta no card pai **CLIENTE KONCILI** com os e-mails solicitados.
10. Aplica a tag `EMAILS_CRIADOS` para evitar duplicidade.

## Controle anti-duplicidade

A tag `EMAILS_CRIADOS` é usada como controle oficial de idempotência.  
Se a tag já existir, o fluxo encerra sem reenviar e-mails e sem criar novos comentários.

## Segurança

O export original do Power Automate continha dados sensíveis e foi sanitizado antes de ser colocado neste repositório.

Não versionar:

- PAT
- Authorization headers
- Bearer tokens
- credenciais Outlook
- IDs internos sensíveis
- URLs internas completas
- e-mails pessoais ou corporativos sensíveis

Consulte [`docs/seguranca.md`](docs/seguranca.md).
