# Changelog

## 1.0.0

- Trigger Azure DevOps por atualização de Work Item.
- Validação da coluna `Fila Seller`.
- Geração automática dos 10 aliases.
- Envio ao Helpdesk.
- Comentário no ADHERENCE KONCILI.
- Comentário detalhado no CLIENTE KONCILI.
- Controle anti-duplicidade com `EMAILS_CRIADOS`.
- Remoção da dependência da extensão de checklist.
- Export sanitizado para GitHub.
