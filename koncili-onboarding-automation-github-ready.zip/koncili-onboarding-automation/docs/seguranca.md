# Segurança

## O que foi removido do export antes do GitHub

- PAT em formato Basic/base64
- Headers `Authorization`
- Identificadores internos em GUID
- E-mails pessoais/corporativos
- Organização e projeto do Azure DevOps
- URLs internas completas
- Nome de ambiente
- Centro de custo

## Atenção

O arquivo original exportado do Power Automate pode conter credenciais em ações HTTP, especialmente quando a autenticação foi configurada manualmente.

Antes de publicar qualquer export:

1. Procurar por `Authorization`
2. Procurar por `Basic `
3. Procurar por `Bearer `
4. Procurar por e-mails reais
5. Procurar por URLs internas
6. Remover ou substituir por placeholders

## Recomendação

Se um PAT foi exportado ou compartilhado em arquivo, revogue/rotacione o PAT e gere outro.
