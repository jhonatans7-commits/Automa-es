# Arquitetura

## Trigger

Azure DevOps:

```text
When a work item is updated
```

O fluxo executa apenas quando a coluna do board é:

```text
Fila Seller
```

Expressão usada:

```text
equals(coalesce(triggerOutputs()?['body/fields/System_BoardColumn'], ''), 'Fila Seller')
```

## Decisão técnica

A extensão de checklist `mohitbagra/workitem-checklist` não foi usada como mecanismo de automação porque seu estado é salvo em storage próprio da extensão e depende de token Bearer temporário do browser.

Estratégia adotada:

```text
Tag EMAILS_CRIADOS + comentários oficiais da API Azure DevOps
```

## Comentários

- **ADHERENCE KONCILI**: recebe o status operacional.
- **CLIENTE KONCILI**: recebe o histórico com os e-mails solicitados.
