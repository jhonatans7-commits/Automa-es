# Operação

## Primeira execução

Quando o card ainda não possui `EMAILS_CRIADOS`:

```text
Ja_Processado = false
```

O fluxo:

- envia e-mail ao Helpdesk;
- comenta no ADHERENCE KONCILI;
- comenta no CLIENTE KONCILI;
- aplica `EMAILS_CRIADOS`.

## Reexecução

Quando o card já possui `EMAILS_CRIADOS`:

```text
Ja_Processado = true
```

O fluxo encerra sem duplicar e-mails ou comentários.

## Mensagem no ADHERENCE KONCILI

```text
✅ E-mails solicitados automaticamente ao Helpdesk com sucesso.
```
